﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TrainTicketMachine.Repository.Models;
using TrainTicketMachine.Repository.Repository;

namespace TrainTicketMachine.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StationController : ControllerBase
    {
        [HttpGet("GetAllbyName")]
        public string GetAllbyName(string input)
        {
            try
            {
                string[] stations = { "DARTFORD", "DARTMOUTH", "TOWER HILL", "DERBY", "LIVERPOOL", "LIVERPOOL LIME STREET", "PADDINGTON", "EUSTON", "LONDON BRIDGE", "VICTORIA" };

                //This Service is calling from the TrainTicketMachine.Repository-->Reference from Models Folder
                List<SearchStationResult> searchResultList = new List<SearchStationResult>();
                //This Service is calling from the TrainTicketMachine.Repository-->Reference from Repository Folder
                StationService sp = new StationService();
                for (int i = 0; i < stations.Length; i++)
                {
                    if (stations[i].StartsWith(input))
                    {
                        searchResultList.Add(new SearchStationResult
                        {
                            station = stations[i],
                            // GetNextCharacter is invoked from StationService
                            nextCharacter = sp.GetNextCharacter(stations[i], input)
                        });
                    }
                }
                string station = "The stations ";


                string characters = "The characters ";

                if (searchResultList.Count == 0)
                {
                    station = "no next characters ";


                    characters = "no stations";
                }
                else
                {
                    foreach (var item in searchResultList)
                    {
                        station += item.station + " ";
                        characters += item.nextCharacter + " ";
                    }
                }
                string result = station + characters;
                return result;
            }
            catch
            {
                return null;
            }
        }
    }
}
