﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainTicketMachine.Repository.Repository
{
    public class StationService
    {
        public char GetNextCharacter(string reference, string input)
        {
            try
            {

                return reference.Replace(input, String.Empty).ToCharArray().ToList()[0];
            }

            catch
            {
                return (char)0;
            }
        }
    }
}
