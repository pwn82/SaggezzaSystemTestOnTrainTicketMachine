﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainTicketMachine.Repository.Models
{
    public class ResultSet
    {
        public List<string> stations { get; set; }
        public List<char> allNextCharacters { get; set; }
        public ResultSet(List<SearchStationResult> searchResults)
        {
            stations = new List<string>();
            allNextCharacters = new List<char>();

            foreach (SearchStationResult s in searchResults)
            {
                stations.Add(s.station);
                allNextCharacters.Add(s.nextCharacter);
            }

            allNextCharacters.Remove(allNextCharacters.Where(c => c == (char)0).FirstOrDefault());
        }
    }
}
