﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrainTicketMachine.Repository.Models
{
    public class SearchStationResult
    {
        public string station { get; set; }
        public char nextCharacter { get; set; }
    }
}
